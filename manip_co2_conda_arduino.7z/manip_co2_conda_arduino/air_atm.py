# -*- coding: utf-8 -*-

def air_atm(ser_GPS,ser_temp,ser_ox,ser_mio,ser_licor,fichier_lecture,fichier_ecriture,temps_rinc_air,temps_mesure_air,monjour,monmois,valeur_graph_pression_1, valeur_graph_pression_2,valeur_graph_pco2, valeur_graph_o2, valeur_graph_temp_sbe38, valeur_graph_temp_opt, valeur_graph_temp_li) :
    print("Air atmospherique")
    type_cycle = 5
    
    debut = time.time()
    actu = debut
    rin = debut + temps_rinc_air # 4 min rincage
    fin = debut + temps_rinc_air + temps_mesure_air # 3 min mesure
    
    control_arduino(ser_mio,'5')
    while rin > actu :
        actu = time.time()
        send_lecture_seule(ser_GPS, ser_temp, ser_ox, ser_mio, ser_licor)
    print("fin du rincage, début des mesures")
    actu = time.time()
    ech = actu + 5
    while fin >= actu :
        actu = time.time()
        if actu >= ech :
            valeur_graph_pression_1, valeur_graph_pression_2,valeur_graph_pco2, valeur_graph_o2, valeur_graph_temp_sbe38, valeur_graph_temp_opt, valeur_graph_temp_li = send_rs232(type_cycle, ser_GPS, ser_temp, ser_ox, ser_mio, ser_licor, fichier_ecriture,valeur_graph_pression_1, valeur_graph_pression_2,valeur_graph_pco2, valeur_graph_o2, valeur_graph_temp_sbe38, valeur_graph_temp_opt, valeur_graph_temp_li) #acauisition
            actu = time.time()
            ech = actu + 5
    print("fin des mesures")
    control_arduino(ser_mio,'0')
    
    fichier_ecriture.close()
    fichier_moyennage(fichier_lecture)
    fichier_lecture,fichier_ecriture,monjour,monmois = ouverture_nouv_fichier_brut(fichier_lecture,fichier_ecriture,monjour,monmois)
    
    return fichier_lecture, fichier_ecriture,monjour,monmois,valeur_graph_pression_1, valeur_graph_pression_2,valeur_graph_pco2, valeur_graph_o2, valeur_graph_temp_sbe38, valeur_graph_temp_opt, valeur_graph_temp_li