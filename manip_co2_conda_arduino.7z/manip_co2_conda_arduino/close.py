# -*- coding: utf-8 -*-

### ferme les ports serial de la MOXA pour les capteurs

def close():
    
    ser.close()    
    ser_temp.close()
    ser_ox.close()
    ser_mio.close() 
    ser_licor.close()
    
close()