# -*- coding: utf-8 -*-
"""
Created on Wed May 30 12:19:27 2018

@author: Paul
"""


### Reception donnees RS232 de l'ensemble des capteurs et periph electronique connecte a la MOXA (multi serie vers usb)
### enregistrement des donnees dans des vecteurs de tailles 250 pour tracer les graph en TR
### decodage des trammes recu
### ecriture des donnees dans le fichier de donnee brut
### renvoie les vecteurs de donnee pour les utiliser dans une autre fonctions

def send_rs232(type_cycle, ser_GPS, ser_temp, ser_ox, ser_mio, ser_licor, fichier, valeur_graph_pression_1, valeur_graph_pression_2,valeur_graph_pco2, valeur_graph_o2, valeur_graph_temp_sbe38, valeur_graph_temp_opt, valeur_graph_temp_li) :
    d1 = 0 # donnee capteur pression 1 (A0)
    d2 = 0 # donnee capteur pression 2 (A1)
    

    while True :
        
         
        if ser_GPS != 0 : #si le module est connecte
            if ser_GPS.in_waiting >= 1: # si des informations arrivent sur la ligne serie
        
                data_GPS = str(ser_GPS.readline()) # conversion en chaine
                while(ser_GPS.in_waiting > 15) : # avoir au moins 2 lignes complete de donne GPS
                                                 # 2 * 7 lignes de donnees gps
                    data_GPS = str(ser_GPS.readline())
                while (data_GPS.split(",")[0] != "b'$GPRMC") : # $GPRMC : ligne contenant les donnees utiles (pos, heure, vitesse, etc)
                    data_GPS = str(ser_GPS.readline())
            else :
                data_GPS = "NaN" 
        else :
            data_GPS = "NaN"
            
        
        if ser_temp != 0 : #si le module est connecte
            if ser_temp.in_waiting >= 1: #une ligne contenant une donnee de temperature
                datatemp = ser_temp.readline() 
                while(ser_temp.in_waiting > 1) :
                    datatemp = ser_temp.readline()
                datatemp = ser_temp.readline() # le capteur envoi seulement un nombre correcpondant a la temp en C
                data_temp = datatemp.decode() # supprime les caracteres issu de la conversion bytes en chaine de cacacteres
            else :
                data_temp = "NaN"
        else :
            data_temp = "NaN"
            
        if ser_ox != 0:
            if ser_ox.in_waiting >= 1 :
                for i in range(300):
                    line = ser_ox.readline()
                    try :
                        data = line.decode()
                    except UnicodeDecodeError : 
                        data = "0000"
                    if len(data) > 4 :
                        if (line[3] == 69) | (line[3] == 17) :
                            data_ox = data
                            break
            else :
                data_ox = "NaN"
        else :
            data_ox = "NaN"
                        
            
        if ser_licor != 0:
            if ser_licor.in_waiting >= 1:
                dlicor = ser_licor.readline()
                while(ser_licor.in_waiting > 1) :
                    dlicor = ser_licor.readline()
                dlicor = ser_licor.readline()
                data_licor = dlicor.decode()
            else :
                data_licor = "NaN"
        else :
            data_licor = "NaN"
            
        
        if ser_mio != 0 :
            
            ### remetre l'arduino dans le bon etat (sinon coupure jsp)
#            if (type_cycle == 1):
#                control_arduino(ser_mio,'1')
#            elif (type_cycle == 2) :
#                control_arduino(ser_mio,'2')
#            elif (type_cycle == 3) :
#                control_arduino(ser_mio,'3')
#            elif (type_cycle == 4) :
#                control_arduino(ser_mio,'4')
#            elif (type_cycle == 5) :
#                control_arduino(ser_mio,'5')
#            elif (type_cycle == 6) :
#                control_arduino(ser_mio,'6')
            
            ### BUG ARDUINO reset vannes a la lecture capteurs pressions
            
            control_arduino(ser_mio,'1')
            time.sleep(1)
            
            dataP1,dataP2 = lecture_arduino(ser_mio,d1,d2,'1')
            
            ###
            
            data_P1 = conv_capt_pression(dataP1,200,900) 
            
            ### Vecteur echantillonage pression 1
            
            if len(valeur_graph_pression_1) >= 250 : # taille vecteur
                valeur_graph_pression_1 = valeur_graph_pression_1[1:] ###si taille vecteur 250 => decalage a gauche
            valeur_graph_pression_1.append(data_P1)
        
            
            ### remetre l'arduino dans le bon etat (sinon coupure jsp)
#            if (type_cycle == 1):
#                control_arduino(ser_mio,'1')
#            elif (type_cycle == 2) :
#                control_arduino(ser_mio,'2')
#            elif (type_cycle == 3) :
#                control_arduino(ser_mio,'3')
#            elif (type_cycle == 4) :
#                control_arduino(ser_mio,'4')
#            elif (type_cycle == 5) :
#                control_arduino(ser_mio,'5')
#            elif (type_cycle == 6) :
#                control_arduino(ser_mio,'6')
                
            control_arduino(ser_mio,'1')
            time.sleep(1)
        
            datap1,datap2 = lecture_arduino(ser_mio,d1,d2,'2')
            data_P2 = conv_capt_pression(dataP2,200,900)
            
            ### valeurs echantillonage pression 2
            
            if len(valeur_graph_pression_2) >= 250 :
                valeur_graph_pression_2 = valeur_graph_pression_2[1:] ###si taille vecteur 250 => decalage a gauche
            valeur_graph_pression_2.append(data_P2)
            
        
        else :
            data_P2 = 0
            data_P1 = 0
            
        ### analyse et decodage des trammes
        ### Tous sauf pressions (pas de verification de "coherence" pour les pressions)
        ### verification de coherence minimale pour les autres capteurs (>0, <max, etc )
              
        data_GPS = decode_frame_GPS(data_GPS)
        data_licor = decode_frame_licor(data_licor)
        data_ox = decode_frame_ox(data_ox)
        data_temp = decode_frame_temp(data_temp)
        
        ### enregistrement des 250 derniers echantillons dans un vecteur
        
        ### vecteurs
        if len(valeur_graph_temp_sbe38) >= 250 :
            valeur_graph_temp_sbe38 = valeur_graph_temp_sbe38[1:]
        valeur_graph_temp_sbe38.append(data_temp)
        
        if len(valeur_graph_temp_opt) >= 250 :
            valeur_graph_temp_opt = valeur_graph_temp_opt[1:]
        valeur_graph_temp_opt.append(data_ox.split()[1])
        
        if len(valeur_graph_o2) >= 250 :
            valeur_graph_o2 = valeur_graph_o2[1:]
        valeur_graph_o2.append(data_ox.split()[0])
        
        if len(valeur_graph_temp_li) >= 250 :
            valeur_graph_temp_li = valeur_graph_temp_li[1:]
        valeur_graph_temp_li.append(data_licor.split()[1])
        
        if len(valeur_graph_pco2) >= 250 :
            valeur_graph_pco2 = valeur_graph_pco2[1:]
        valeur_graph_pco2.append(data_licor.split()[0])
                
        ecriture(type_cycle, data_GPS, data_temp, data_P1, data_P2, data_licor, data_ox, fichier)
        
        
        ### Affichage des courbes de donnees sur les 250 derniers echantillons
        
        
        ### graph pression
        
        fig = plt.subplot(2,2,1)
        fig = plt.plot(valeur_graph_pression_1, label='AD0')
        fig = plt.plot(valeur_graph_pression_2, label = 'AD1')
        fig = plt.title('Pression AD0 et AD1')
        fig = plt.ylabel("hPa")
        fig = plt.show()
        
        ### Graph taux de CO2
        
        fig = plt.subplot(2,2,2)
        fig = plt.plot(valeur_graph_pco2)
        fig = plt.title('Taux de CO2')
        fig = plt.ylabel("ppm")
        fig = plt.show()
        
        ### graph taux de O2
        
        fig = plt.subplot(2,2,3)
        fig = plt.plot(valeur_graph_o2)
        fig = plt.title('Taux de O2')
        fig = plt.ylabel("??")
        fig = plt.show()
        
        ### graph temperature eau et Licor
        
        fig = plt.subplot(2,2,4)
        fig = plt.plot(valeur_graph_temp_li, label='licor')
        fig = plt.plot(valeur_graph_temp_opt, label='opt')
        fig = plt.plot(valeur_graph_temp_sbe38, label='SBE38')
        fig = plt.title('temp')
        fig = plt.ylabel("C")
        fig = plt.show()
        
        return valeur_graph_pression_1, valeur_graph_pression_2,valeur_graph_pco2, valeur_graph_o2, valeur_graph_temp_sbe38, valeur_graph_temp_opt, valeur_graph_temp_li