# -*- coding: utf-8 -*-


### initialisation des peripherique connecte a la moxa :
### arduino
### optode
### GPS
### Licor
### SBE38
### retourne les instance de connexion serie afin de les utiliser dans le programme

def initialisation_moxa():
    
    ### port COM correspondant au indication sur la moxa 
    ### + connecte la MOXA au PC portable IRENE sur le port USB gauche
    ### !! Attention les ports COM peuvent changer dans une autre config
    
    port1 = "COM17"
    port2 = "COM16" 
    port3 = "COM14" 
    port5 = "COM13"
    
    ser_arduino = 0
    
    try :
        ser_arduino = initialisation_arduino(ser_arduino)
    except :
        ser_arduino = 0
        print("initialisation arduino echoue dans la fonction initialisation_moxa()")
    
    try :
        ser_GPS = serial.Serial(port1,
                                baudrate=4800,
                                parity=serial.PARITY_NONE,
                                stopbits=serial.STOPBITS_ONE, 
                                bytesize=serial.EIGHTBITS)
        
    except serial.SerialException :
        ser_GPS = 0
        print("Erreur module GPS non detectee sur la liaison serie")
    except :
        ser_GPS = 0
        print("Erreur GPS non fonctionnel")
    
    try :
            ser_temp = serial.Serial(port2,
                                     baudrate=9600,
                                     parity=serial.PARITY_NONE,
                                     stopbits=serial.STOPBITS_ONE,
                                     bytesize=serial.EIGHTBITS)
            
    except serial.SerialException :
        ser_temp = 0
        print("Erreur sonde SBE38 non detectee sur la liaison serie")
    except :
        ser_temp = 0
        print("Erreur sonde SBE38 non fonctionnelle")
    
    try :
        ser_ox = serial.Serial(port3,
                               baudrate=9600,
                               parity=serial.PARITY_NONE,
                               stopbits=serial.STOPBITS_ONE,
                               bytesize=serial.EIGHTBITS)
        
    except serial.SerialException :
        ser_ox = 0
        print("Erreur optode non detectee sur la liaison serie")
    except :
        ser_ox = 0
        print("Erreur optode non fonctionnelle")
        
    
    try :
        ser_licor = serial.Serial(port5,
                                  baudrate=9600,
                                  parity=serial.PARITY_NONE,
                                  stopbits=serial.STOPBITS_ONE,
                                  bytesize=serial.EIGHTBITS)
        
    except serial.SerialException :
        ser_licor = 0
        print("Erreur detecteur IR Licor non detecte sur la liaison serie")
    except :
        ser_licor = 0
        print("Erreur detecteur IR Licor non fonctionnel")
        
    
    if (ser_ox != 0) :
        config_oxy(ser_ox)
    
    return ser_GPS, ser_temp, ser_ox, ser_arduino, ser_licor

