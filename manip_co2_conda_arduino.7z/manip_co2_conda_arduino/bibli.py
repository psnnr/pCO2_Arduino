# -*- coding: utf-8 -*-

### executer les sous fonctions du programme pour qu'il les reconnaise
### a faire avant de lancer principal
### une fois le fichier execute lancer le programme bibli()
### possible de l'integrer au main, mais une erreur apparait en fin d'execution du programme 

def bibli():
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/air_atm.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/azote.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/config_oxy.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/conv_capt_pression.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/decode_frame_GPS.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/decode_frame_licor.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/decode_frame_ox.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/decode_frame_temp.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/eau_mers.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/ecriture.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/enchain_cycle.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/etal_bas.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/etal_haut.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/etal_moy.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/evac_piege_froid.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/fichier_moyennage.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/get_jour.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/get_mois.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/init_lecture_fichier_brut.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/initialisation_moxa.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/message_initialisation_manipulation.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/nouv_fichier_ecriture.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/nouv_fichier.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/ouverture_nouv_fichier_brut.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/sechage_licor.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/send_lecture_seule.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/send_rs232.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    runfile('C:/Users/Nathalie/Documents/manip_co2_conda_arduino/test_arduino_uno.py', wdir='C:/Users/Nathalie/Documents/manip_co2_conda_arduino')
    