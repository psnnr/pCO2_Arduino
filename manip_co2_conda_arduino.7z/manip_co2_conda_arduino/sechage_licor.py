# -*- coding: utf-8 -*-
"""
Created on Thu Nov  8 15:30:11 2018

@author: StageCO2
"""

def sechage_licor(ser_mio):
    
    print()
    print("sechage du détecteur infrarouge Licor pendant 1 minutes")
    
    vanne = bytes("BD1F00\n\r",'utf-8') #commande ouverture vanne 1,2,3 et 4
    ser_mio.write(vanne) #envoi commande
    
    actu = time.time()
    fin = actu + 1*60
    
    while(actu<fin):
        actu = time.time()
        
    print()
    print("fin du séchage du détecteur Licor")
    print
    
    