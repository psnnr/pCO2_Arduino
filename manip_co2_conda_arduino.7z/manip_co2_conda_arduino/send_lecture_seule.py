# -*- coding: utf-8 -*-

### lit les capteurs mais n'ecris rien dans le fichier et le terminal ###

def send_lecture_seule(ser_GPS, ser_temp, ser_ox, ser_mio, ser_licor) :
        
        
    if ser_GPS != 0 :
        if ser_GPS.in_waiting >= 1:
            data_GPS = str(ser_GPS.readline())
            while(ser_GPS.in_waiting > 15) :
                data_GPS = str(ser_GPS.readline())
            while (data_GPS.split(",")[0] != "b'$GPRMC"):
                data_GPS = str(ser_GPS.readline())
                
        else :
            data_GPS = "NaN"
    
    else :
        data_GPS = "NaN"
        
        
    if ser_temp != 0 :
        if ser_temp.in_waiting >= 1:
            datatemp = ser_temp.readline()
            while(ser_temp.in_waiting > 1) :
                datatemp = ser_temp.readline()   
            datatemp = ser_temp.readline()
            data_temp = datatemp.decode()
            
        else :
            data_temp = "NaN"
            
    else :
        data_temp = "NaN"
        

    if ser_ox != 0:
        if ser_ox.in_waiting >= 1 :
            for i in range(300):
                line = ser_ox.readline()
                try :
                    data = line.decode()
                except UnicodeDecodeError :
                    data = "0000"
                if len(data) > 4 :
                    if (line[3] == 69) | (line[3] == 17) :
                        data_ox = data
                        break
        else :
            data_ox = "NaN"
    else :
        data_ox = "NaN"
    
    if ser_licor != 0:
        if ser_licor.in_waiting >= 1:
            dlicor = ser_licor.readline()
            while(ser_licor.in_waiting > 1) :
                dlicor = ser_licor.readline()
            data_licor = dlicor.decode()
        else :
            data_licor = "NaN"
    else :
        data_licor = "NaN"

    return 0