# -*- coding: utf-8 -*-


### conversion de la valeur renvoyer par la carte arduino
### (hexadecimal sur 10 bits) en valeur reel
### Attention Arduino analogique sur 5V (10b)
### Capteur pression PBT sur 0-2.5V

def conv_capt_pression(var1,var2,var3) :
    ### var1 = valeur hexadecimal mesuree
    ### var2 = plage de mesure
    ### var3 = min
    
    try:
        i = float(var1)
        n = ((i/512) * var2) + var3
        ### 512 car 2^10 sur 5v (Arduino) => 2^9 sur 2.5V (capteur pression)
        
    except ValueError :
        n = "NaN"
    return n

