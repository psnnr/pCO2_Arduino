# -*- coding: utf-8 -*-
"""
Created on Mon Dec 17 14:48:58 2018

@author: Nathalie
"""

"""""  Importation bibliotheques """""

import serial
import time

"""""  definition des fonctions et procedures """""

def initialisation_arduino(ser_arduino):
    try:
        ser_arduino = serial.Serial("COM3",baudrate=9600, timeout=1) #Definition de l'objet serial sur le port 3

    except:
        print('carte Arduino illisible')

    print("Caracteristique carte arduino : ",ser_arduino)
    
    return ser_arduino

def fermeture_communication_arduino(ser_arduino):
    try :
        ser_arduino.close()
    except AttributeError :
        print("No serial connexion with Arduino")
    except :
        print("Error close serial connexion")
        

def control_arduino(ser_arduino,cmd):

    if (cmd == '1'):
        code = '1';
        ser_arduino.write(code.encode('utf-8'))  # envoyer le code a l'arduino
    elif (cmd == '2'):  # activation des vannes cycle 2 : etal. bas
         code = '2';
         ser_arduino.write(code.encode('utf-8'))  # envoyer le code a l'arduino
    elif (cmd == '3'):  # activation des vannes cycle 3 : etal. haut
         code = '3';
         ser_arduino.write(code.encode('utf-8'))  # envoyer le code a l'arduino
    elif (cmd == '4'):  # activation des vannes cycle 4 : etal. med.
         code = '4';
         ser_arduino.write(code.encode('utf-8'))  # envoyer le code a l'arduino
    elif (cmd == '5'):  # activation des vannes cycle 5 : air atm.
         code = '5';
         ser_arduino.write(code.encode('utf-8'))  # envoyer le code a l'arduino
    elif (cmd == '6'):  # activation des vannes cycle 6 : eau de mer
         code = '6';
         ser_arduino.write(code.encode('utf-8'))  # envoyer le code a l'arduino
    elif (cmd == '0'):  # fermeture des vannes
         code = '0';
         ser_arduino.write(code.encode('utf-8'))  # envoyer le code a l'arduino
    elif() :
        print("commmande incorect")



def lecture_arduino(ser_arduino,dataP1,dataP2,channel):

    data_sensor = "" #chaine de caractre contenant les informations lu sur la voie analogique
    data_final = "" #donnees decodees

    if (channel == '1'): #lecture de la premiere voie analogique
        code = '8'; #code a envoyer sur la carte arduino pour effectuer la lecture du channel 1
        ser_arduino.write(code.encode('utf-8'))  # envoyer le code a l'arduino
        data_sensor = ser_arduino.readline() #releve brut de la valeur analogique lu sur la carte
        print(data_sensor)
        data_final = data_sensor.decode() #decodage trame rs232
        print("valeur recu de la carte arduino pour le capteur de pression 1 : {:>4}".format(data_final))

        try :
            dataP1 = int(data_final)
        except ValueError :
            dataP1 = 0
            print("erreur conversion data 1 final en entier")

    elif (channel == '2'): #lecture de la deuxieme voie analogique
        code = '9'; #code a envoyer sur la carte arduino pour effectuer la lecture du channel 2
        ser_arduino.write(code.encode('utf-8'))  # envoyer le code a l'arduino
        data_sensor = ser_arduino.readline() #releve brut de la valeur analogique lu sur la carte
        data_final = data_sensor.decode()
        print("valeur recu de la carte arduino pour le capteur de pression 2 : {:>4}".format(data_final))
        try :
            dataP2 = int(data_final)
        except ValueError :
            dataP2 = 0
            print("errreur conversion data 2 final en entier")
    elif() :
        print("Voie lecture inexistante")


    return dataP1,dataP2

"""" debut du programme de test/debbog """

"""" definition des variables """

#com = 1
ser = 0
d1 = 0
d2 = 0

""""" execution des instructions """

ser = initialisation_arduino(ser)

time.sleep(2)

control_arduino(ser,'2')
time.sleep(4)
d1,d2 = lecture_arduino(ser,d1,d2,'1')
print(d1)
d1,d2 = lecture_arduino(ser,d1,d2,'1')
print(d2)
time.sleep(4)
d1,d2 = lecture_arduino(ser,d1,d2,'1')
print(d1)
d1,d2 = lecture_arduino(ser,d1,d2,'1')
print(d2)
time.sleep(4)
control_arduino(ser,'6')
time.sleep(4)
d1,d2 = lecture_arduino(ser,d1,d2,'1')
print(d1)
d1,d2 = lecture_arduino(ser,d1,d2,'1')
print(d2)
time.sleep(4)
d1,d2 = lecture_arduino(ser,d1,d2,'1')
print(d1)
d1,d2 = lecture_arduino(ser,d1,d2,'1')
print(d2)
fermeture_communication_arduino(ser)