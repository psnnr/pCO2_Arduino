# -*- coding: utf-8 -*-

### declenche le cycle de mesure sur azote
### en general : 3 min rincage, 3 min mesure
### recuperation des donnees capteurs dans la fonction send_RS232
###

def azote(ser_GPS, ser_temp, ser_ox, ser_mio, ser_licor,fichier_lecture, fichier_ecriture,temps_rinc_azote,temps_mesure_azote, monjour, monmois,valeur_graph_pression_1, valeur_graph_pression_2,valeur_graph_pco2, valeur_graph_o2, valeur_graph_temp_sbe38, valeur_graph_temp_opt, valeur_graph_temp_li) :
    print("Azote")
    type_cycle = 1 
    
    debut = time.time() 
    actu = debut
    rin = debut + temps_rinc_azote  #3 min rincage
    fin = debut + temps_rinc_azote + temps_mesure_azote #3min mesure
    
    control_arduino(ser_mio,'1')
    
    print("début du rincage")
    while rin > actu :
        actu = time.time()
        send_lecture_seule(ser_GPS, ser_temp, ser_ox, ser_mio, ser_licor) # lire les ports series sans enregistrer afin d'eviter l'accumulation des donnees a l'arrivee
    print("fin du rincage, début des mesures")
    while fin >= actu:
        actu = time.time()
        # lecture et enregistrement des donnees a la frequence d'echantillonage (5 sec)
        valeur_graph_pression_1, valeur_graph_pression_2,valeur_graph_pco2, valeur_graph_o2, valeur_graph_temp_sbe38, valeur_graph_temp_opt, valeur_graph_temp_li = send_rs232(type_cycle, ser_GPS, ser_temp, ser_ox, ser_mio, ser_licor, fichier_ecriture,valeur_graph_pression_1, valeur_graph_pression_2,valeur_graph_pco2, valeur_graph_o2, valeur_graph_temp_sbe38, valeur_graph_temp_opt, valeur_graph_temp_li) #acauisition
    print("fin des mesures")
    
    
    ### enregistrement des données moyennées du cycle Azote
    
    fichier_ecriture.close()
    fichier_moyennage(fichier_lecture)
    fichier_lecture,fichier_ecriture,monjour,monmois = ouverture_nouv_fichier_brut(fichier_lecture,fichier_ecriture,monjour,monmois)
    
    return fichier_lecture, fichier_ecriture,monjour,monmois, valeur_graph_pression_1, valeur_graph_pression_2,valeur_graph_pco2, valeur_graph_o2, valeur_graph_temp_sbe38, valeur_graph_temp_opt, valeur_graph_temp_li