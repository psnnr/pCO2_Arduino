# -*- coding: utf-8 -*-

### Ce programme sert a lire et interpreter les resultats obtenus lors de la manipulation
### Il permet de tracer different graphe de donnees
### Ainsi que la droite d'etalonage du Licor
### Peut sevir en face de test avance pour verifier la coherence des donnees

from scipy import stats
import numpy as np
import matplotlib.pyplot as plt

### Vecteurs contenant l'ensemble des donnees lues dans les fichiers de donnees (brut ou moyenne)
tab_co2 = []
tab_h2o = []
tab_heure = []
tab_cycle = []
tab_temp_sbe38 = []
tab_temp_opt = []
etal_bas = []
etal_med = []
etal_haut = []

def lecture_CO2(tab_cycle,tab_co2,tab_h2o,tab_temp_sbe38):
    
#    fich = open("data/Data_Brut_29-11.txt",'r')
#    data = fich.readline()
#    data = data.split()
#    while(data[0] == "cycle"):
#        data = fich.readline()
#    
#    while(data):
#        line = data.split()
#        tab_co2.append(float(line[10]))
#        tab_h2o.append(float(line[11]))
#        tab_heure.append(line[2])
#        tab_temp_sbe38.append(float(line[7]))
#        tab_temp_opt.append(float(line[15]))
#        tab_cycle.append(int(line[0]))
#        data = fich.readline()
#        
#        
#    fich.close()
    
    fich = open("data/Data_Brut_30-11.txt",'r')
    data = fich.readline()
    data = data.split()
    while(data[0] == "cycle"):
        data = fich.readline()
    
    while(data):
        line = data.split()
        tab_co2.append(float(line[10]))
        tab_h2o.append(float(line[11]))
        tab_heure.append(line[2])
        tab_temp_sbe38.append(float(line[7]))
        tab_temp_opt.append(float(line[15]))
        tab_cycle.append(int(line[0]))
        data = fich.readline()
        
        
    fich.close()
    
    
    return tab_cycle,tab_co2,tab_h2o,tab_temp_sbe38

        
    

def trace_etal(tab_cycle,etal_bas,etal_med,etal_haut):
    
    imin = 0
    imin2 = 0
    imin3 = 0
    imax1 = 0
    imax2 = 0
    imax3 = 0
    
    p1 = False
    p2 = False
    p3 = False
    
    
    for i in range (0,len(tab_cycle)):
        
        
        if tab_cycle[i] == 3 :
            if p2 == False :
                imin2 = i
                p2 = True
            imax2 = i
        
        if tab_cycle[i] == 2 :
            if p1 == False :
                imin = i
                p1 = True
            imax = i
                
        if tab_cycle[i] == 4 :
            if p3 == False:
                imin3 = i
                p3 = True
            imax3 = i
        
        etal_bas = [imin,imax]
        etal_haut = [imin2,imax2]
        etal_med = [imin3,imax3]
    
    return etal_bas,etal_med,etal_haut

def trace_graph_temp(tab_temp_opt,tab_temps_sbe38):
        
    fig, ax1 = plt.subplots()
    plt.grid(True)
    ax1.plot(tab_temp_opt, color = 'b', label = "Optode")

    ax1.set_ylabel('temperature Celsius', color="purple")
    ax1.plot(tab_temp_sbe38,color = "purple",linewidth = 2.0, label = "SBE38")
    
    ax1.legend()

    plt.show()
        

def trace_graph_co2_temp(tab_temp_opt,tab_temps_sbe38):
        
    fig, ax1 = plt.subplots()
    plt.grid(True)
    ax2 = ax1.twinx()
    ax1.set_ylabel('CO2 ppm', color='b')
    ax1.plot(tab_co2, color = 'b', label = "taux CO2")

    ax2.set_ylabel('temperature SBE38 Celsius', color="purple")
    ax2.plot(tab_temp_sbe38,color = "purple",linewidth = 2.0, label = "C")
    ax2.set_title("mesure CO2 et temperature du 30 novembre dans la journee")
    
    ax2.legend()
    n = 5000
    xtn=np.arange(0,n,1000)
    
    xticklabels = ['30/11 9h10','30/11 10h35', '30/11 12h','30/11 13h25', '30/11 15h50']


    plt.xticks(xtn,xticklabels)

    plt.show()
    
def trace_graph_co2_h2o(tab_co2,tab_h2o):
        
    fig, ax1 = plt.subplots()
    plt.grid(True)
    ax2 = ax1.twinx()
    ax1.set_ylabel('co2 ppm', color='b')
    ax1.plot(tab_co2, color = 'b', label = "taux CO2")

    ax2.set_ylabel('h2o Licor', color="purple")
    ax2.plot(tab_h2o,color = "purple",linewidth = 2.0, label = "h2o licor")
    ax2.set_title("mesure CO2 et H2O du 30 novembre dans la journee")
    ax1.legend()

    ax2.legend()
    n = 5000
    xtn=np.arange(0,n,1000)
    
    xticklabels = ['30/11 9h10','30/11 10h35', '30/11 12h','30/11 13h25', '30/11 15h50']



    plt.xticks(xtn,xticklabels)

    plt.show()
    
def trace_graph2(tab_co2,tab_h2o,etal_bas,etal_haut,etal_med):
        
    fig, ax1 = plt.subplots()
    plt.grid(True)
    ax2 = ax1.twinx()
    ax1.set_ylabel('co2 ppm', color='b')
    ax1.plot(tab_co2, color = "b")
    ax1.plot(etal_bas,[282.28,282.28],color="green",linewidth=3.0)
    ax1.plot(etal_haut,[479.85,479.85],color="red",linewidth=3.0)
    ax1.plot(etal_med,[351.30,351.30],color="orange",linewidth=3.0)
    ax2.set_ylabel('h2o', color="purple")
    ax2.plot(tab_h2o,color = "purple",linewidth = 3.0)

    plt.show()
    
    
def moy(tab_co2):
    mb1=0
    mh1=0
    mm1=0
    mb2=0
    mh2=0
    mm2=0
    mb3=0
    mh3=0
    mm3=0
    mb4=297.48249999999996
    mb5=304.73999999999995
    mh4=449.8291666666667
    mh5=457.9941666666668
    mm4=349.3983333333333
    mm5=355.0133333333334

        
    
    for i in range (79,91):
        mb1 = mb1 + tab_co2[i]
    for i in range (154,166):
        mh1 = mh1 + tab_co2[i]
    for i in range (228,240):
        mm1 = mm1 + tab_co2[i]
    mb1 = mb1/12
    mh1 = mh1/12
    mm1 = mm1/12
    for i in range (4081,4093):
        mb2 = mb2 + tab_co2[i]
    for i in range (4154,4166):
        mh2 = mh2 + tab_co2[i]
    for i in range (4228,4240):
        mm2 = mm2 + tab_co2[i]
    mb2 = mb2/12
    mh2 = mh2/12
    mm2 = mm2/12
    for i in range (8079,8091):
        mb3 = mb3 + tab_co2[i]
    for i in range (8153,8165):
        mh3 = mh3 + tab_co2[i]
    for i in range (8227,8239):
        mm3 = mm3 + tab_co2[i]
    mb3 = mb3/12
    mh3 = mh3/12
    mm3 = mm3/12
    print("moyenne bas 1 : ", mb1)
    print("moyenne haut 1 : ",mh1)
    print("moyenne med 1 : ",mm1)
    print("moyenne bas 2 : ", mb2)
    print("moyenne haut 2 : ", mh2)
    print("moyenne med 2 : ", mm2)
    print("moyenne bas 3 : ", mb3)
    print("moyenne haut 3 : ", mh3)
    print("moyenne med 3 : ", mm3)
    
    
    plt.grid(True)
    [a,b,r,pv,stderr] = stats.linregress([mb1,mb2,mb3,mb4,mb5,mm1,mm2,mm3,mm4,mm5,mh1,mh2,mh3,mh4,mh5],[282.28,282.28,282.28,282.28,282.28,351.30,351.30,351.30,351.30,351.30,479.85,479.85,479.85,479.85,479.85])
    print("equation de la droite : ",a,"x + ",b)
    print("coefficient de correlation : ", r*r)
    gr = r*r
    
    fig, ax = plt.subplots()
    ax.scatter([mb1,mm1,mh1],[282.28,351.30,479.85], marker='*')
    ax.scatter([mb2,mm2,mh2],[282.28,351.30,479.85], marker='*')
    ax.scatter([mb3,mm3,mh3],[282.28,351.30,479.85], marker='*')
    ax.scatter([297.48249999999996, 349.3983333333333,449.8291666666667],[282.28,351.30,479.85], marker='.')
    ax.scatter([304.73999999999995,355.0133333333334,457.9941666666668],[282.28,351.30,479.85], marker='.')
    
    ax.set(xlabel='valeurs licor xCO2', ylabel='valeurs bouteilles xCO2', title='droite licor/étalons')
    y1 = [a*(280)+b,a*(485) + b]
    x1 = [280,485]
    ax.grid()
    ax.plot(x1,y1,color='r',label = '29 et 30 novembre : f(x) = {:.4f} x {:.4f} et corrélation (r*r={:.4f})'.format(a,b,gr))
    
#    a = 1.3243
#    b = -118.3425
#    gr = 0.9993
#    
#
#    y1 = [a*(280)+b,a*(485) + b]
#    x1 = [280,485]
#    ax.plot(x1,y1,color='b', label = 'jour1 : f(x) = {:.4f} x {:.4f} et corrélation (r*r={:.4f})'.format(a,b,gr))
    
#    a = 2.1131
#    b = -546.2707
#    gr =  0.9274
#    
#    y1 = [a*(350)+b,a*(500) + b]
#    x1 = [350,500]
#    ax.plot(x1,y1,color='g', label = 'jour2 : f(x) = {:.4f} x {:.4f} et corrélation (r*r={:.4f})'.format(a,b,gr))
    
    ax.legend()
    
    

    
#    enrg = open("data/graph/Pts_6-11_droite_licor.txt","a")
#    enrg.write("equation         correlation        Pts  \n")
#    lol = str(a) + "   " + str(b) + "       " + str(r*r)  + "         " + str(mb1) + "  "+str(mh1)+"  "+str(mm1)+"  "+str(mb2)+"  "+str(mh2)+"  "+str(mm2)
#    enrg.write(lol)
    
def moy2(tab_co2):
    mb1=0
    mh1=0
    mm1=0
    fich = open("data/Data_Brut_8-11.txt",'r')
    data = fich.readline()
    data = data.split()
    while(data[0] == "cycle"):
        data = fich.readline()
        
    
    for i in range (79,91):
        mb1 = mb1 + tab_co2[i]
    for i in range (171,183):
        mh1 = mh1 + tab_co2[i]
    for i in range (262,274):
        mm1 = mm1 + tab_co2[i]
    mb = mb1/12
    mh = mh1/12
    mm = mm1/12

    print("moyenne bas 1 : ", mb)
    print("moyenne haut 1 : ",mh)
    print("moyenne med 1 : ",mm)

    
    
    [a,b,r,pv,stderr] = stats.linregress([mb,mm,mh],[282.28,351.30,479.85])
    print("equation de la droite : ",a,"x + ",b)
    print("coefficient de correlation : ", r*r)
    gr = r*r
    
    fig, ax = plt.subplots()
    ax.scatter([mb,mm,mh],[282.28,351.30,479.85], marker='D',label = "Jour 2")
    ax.grid(True)
    ax.set(xlabel='valeurs licor', ylabel='valeurs étalons', title='droite licor/étalons ')
    y1 = [a*(380)+b,a*(500) + b]
    x1 = [380,500]
    ax.plot(x1,y1,color='b',label = '{:.4F} * x + {:.4F}  (r*r : {:.4F})'.format(a,b,gr))

    
    enrg = open("data/graph/Pts_6-11_droite_licor.txt","r")
    doyt = enrg.readline()
    doyt = enrg.readline()
    doyt = doyt.split()
    a = float(doyt[0])
    b = float(doyt[1])
    r = float(doyt[2])
    pb1 = float(doyt[3])
    ph1 = float(doyt[4])
    pm1 = float(doyt[5])
    pb2 = float(doyt[6])
    ph2 = float(doyt[7])
    pm2 = float(doyt[8])
    
    #fig,ax2 = plt.subplots()
    
    ax.scatter([pb1,pb2,pm1,pm2,ph1,ph2],[282.28,282.28,351.30,351.30,479.85,479.85], marker='o', label = "Jour 1" )
    ax.scatter([301.13416666666666,355.23,457.09999999999997],[282.28,351.30,479.85], marker='+', color = "purple", label = "Jour 3")
    y2 = [a*(250) + b ,a*(485) + b]
    x2 = [250,485]
    ax.plot(x2,y2,color='r', label = '{:.4F} * x + {:.4F}  (r*r : {:.4F})'.format(a,b,r*r))
    ax.legend()
    #ax2.grid(True)
    
    

def moy_mesures_co2_temp(tab_co2,tab_h2o):
    
    mco2d = 0
    mtempd = 0
    mco2f = 0
    mtempf = 0
    
    for i in range (3660,4020):
        mco2d = mco2d + tab_co2[i]
        mtempd = mtempd + tab_temp_sbe38[i]
    for i in range (7216,7576):
        mco2f = mco2f + tab_co2[i]
        mtempf = mtempf + tab_temp_sbe38[i]
        
    mco2f = mco2f / 360
    mco2d = mco2d / 360
    mtempf = mtempf / 360
    mtempd = mtempd /360
    
    print("premier cycle co2 : {:.5f}".format(mco2d))
    print("premier cycle temp : {:.5f}".format(mtempd))
    print("deuxième cycle co2 : {:.5f}".format(mco2f))
    print("deuxieme cycle temp : {:.5f}".format(mtempf))
    

        
    
tab_cycle,tab_co2,tab_h2o,tab_temp_sbe38 = lecture_CO2(tab_cycle,tab_co2,tab_h2o,tab_temp_sbe38)

etal_bas,etal_med,etal_haut = trace_etal(tab_cycle,etal_bas,etal_med,etal_haut)
#moy(tab_co2)

trace_graph_co2_h2o(tab_co2,tab_h2o)
trace_graph_co2_temp(tab_co2,tab_temp_sbe38)


#moy_mesures_co2_temp(tab_co2,tab_h2o)


