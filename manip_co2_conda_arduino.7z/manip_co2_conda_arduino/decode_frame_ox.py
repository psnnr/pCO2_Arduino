# -*- coding: utf-8 -*-

### decode et analyse tramme optode
### 2 infos a recup :
### taux O2 puis temp eau

def decode_frame_ox(var1):
    wr1 = str(var1)
    l = wr1.split()
    try :
        h = l[4] + "    " + l[8]
    except IndexError :
        h = "NaN" + "    " + "NaN"
    except :
        h = "NaN" + "    " + "NaN"
    return h