# -*- coding: utf-8 -*-

def tracer_graph(fichier_lecture,fichier_ecriture,monjour,monmois):
    fichier_ecriture.close()
    name = "data/Data_Brut_" + str(monjour) + "-" + str(monmois) + ".txt"
    fich_lecture = open(name,"r")
    listeP1 = []
    listeP2 = []
    cpt = 1
    liste_cpt = []
    while(fich_lecture.readline):
        read_data = fich_lecture.readline()
        h = read_data.split()
        print(read_data)
        print(h)
        listeP1.append(h[8])
        listeP2.append(h[9])
        liste_cpt.append(cpt)
        cpt = cpt + 1
    plt.plot(listeP1, liste_cpt,listeP2, liste_cpt)
    fich_lecture.close()
    fichier_lecture,fichier_ecriture,monjour,monmois = ouverture_nouv_fichier_brut(fichier_lecture,fichier_ecriture,monjour,monmois)
    return 0