# -*- coding: utf-8 -*-

def fichier_moyenne_cycle_court(fichier,cpt_lignes):
    m1 = 0
    m2 = 0
    m3 = 0
    m4 = 0
    m5 = 0
    m6 = 0
    m7 = 0
    m8 = 0
    


    for i in range(cpt_lignes,cpt_lignes + 36):
        read_data = fichier.readline()
        V = read_data.split()        
        m1 = m1 + float(V[7])
        m2 = m2 + float(V[8])
        m3 = m3 + float(V[9])
        m4 = m4 + float(V[10])
        m5 = m5 + float(V[11])
        m6 = m6 + float(V[12])
        m7 = m7 + float(V[13])
        m8 = m8 + float(V[14])
    
    m1 = m1/36
    m2 = m2/36
    m3 = m3/36
    m4 = m4/36
    m5 = m5/36
    m6 = m6/36
    m7 = m7/36
    m8 = m8/36
    
    fich = open("data/DataMoyenne.txt","a")
    fich.write(V[0])
    fich.write("    ")
    fich.write(V[1])
    fich.write("    ")
    fich.write(V[2])
    fich.write("    ")
    fich.write(V[3])
    fich.write("    ")
    fich.write(V[4])
    fich.write("    ")
    fich.write(V[5])
    fich.write("    ")
    fich.write(V[6])
    fich.write("    ")
    fich.write(str(m1))
    fich.write("    ")
    fich.write(str(m2))
    fich.write("    ")
    fich.write(str(m3))
    fich.write("    ")
    fich.write(str(m4))
    fich.write("    ")
    fich.write(str(m5))
    fich.write("    ")
    fich.write(str(m6))
    fich.write("    ")
    fich.write(str(m7))
    fich.write("    ")
    fich.write(str(m8))
    fich.write("\n")
    
    fich.close()
    cpt_lignes = cpt_lignes + 36
    return cpt_lignes