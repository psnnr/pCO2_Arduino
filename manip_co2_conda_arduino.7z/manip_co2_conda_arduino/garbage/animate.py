# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import time
cpt = 1


def animate(i,ax1):
    global cpt
    pullData = open("sampleText.txt","r").read()
    dataArray = pullData.split('\n')
    xar = []
    yar = []
    for eachLine in dataArray:
        if len(eachLine)>1:
            u = eachLine.split()
            y = u[7]
            x = cpt
            xar.append(float(x))
            yar.append(float(y))
            cpt = cpt + 1
    ax1.clear()
    ax1.plot(xar,yar)