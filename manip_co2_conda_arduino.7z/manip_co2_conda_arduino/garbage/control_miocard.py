# -*- coding: utf-8 -*-

def control_miocard(var1):
    b = bytes("Id\n\r",'utf-8')
    var1.write(b)
    
    b = bytes("AT000\n\r",'utf-8')
    var1.write(b)
    
    b = bytes("BD0000\n\r",'utf-8')
    var1.write(b)
    
    a = var1.readline()
    