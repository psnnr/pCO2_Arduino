# -*- coding: utf-8 -*-

def analyser_frame_GPS(var1,var2,var3,var4,var5,var6,var7,var8,var9) :
    
    if var1[3] == 82 and var1[4] == 77 and var1[5] == 67 :
        return var1
    elif var2[3] == 82 and var2[4] == 77 and var2[5] == 67 :
        var1 = var2
        return var1
    elif var3[3] == 82 and var3[4] == 77 and var3[5] == 67 :
        var1 = var3
        return var1
    elif var4[3] == 82 and var4[4] == 77 and var4[5] == 67 :
        var1 = var4
        return var1
    elif var5[3] == 82 and var5[4] == 77 and var5[5] == 67 :
        var1 = var5
        return var1
    elif var6[3] == 82 and var6[4] == 77 and var6[5] == 67 :
        var1 = var6
        return var1
    elif var7[3] == 82 and var7[4] == 77 and var7[5] == 67 :
        var1 = var7
        return var1
    elif var8[3] == 82 and var8[4] == 77 and var8[5] == 67 :
        var1 = var8
        return var1
    elif var9[3] == 82 and var9[4] == 77 and var9[5] == 67 :
        var1 = var9
        return var1
    else:
        print("trame GPS non trouvée")
    
        