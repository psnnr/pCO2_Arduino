# -*- coding: utf-8 -*-
"""
Created on Thu Nov  8 12:08:01 2018

@author: StageCO2
"""

def message_initialisation_manipulation(temps_mesure_eau):
    
    print("#################################")
    print()
    print("Pensez a démarer le refroidiseur 15 minutes avant le lancement des mesures !")
    print()
    print("pensez a brancher la pompe a eau si mesure de l'eau de mer et pompe à air si mesure sur l'air atmosphérique")
    print()
    print("pensez a allumer le GPS !! Ainsi que le boitier interface et le Licor")
    print()
    print()
    print("pensez a ouvrir les bonbonnes de gar étalons si etallonages !")
    print()
    print("pensez a brancher la carte arduino")
    print()
    print("Temps de mesure de l'eau de mer : {:d} minutes".format(temps_mesure_eau))
    print()
    print("#################################")