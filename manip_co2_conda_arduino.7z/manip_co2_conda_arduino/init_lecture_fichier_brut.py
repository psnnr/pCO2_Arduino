# -*- coding: utf-8 -*-

def init_lecture_fichier_brut(fichier):
    
    line = fichier.readline()
    while(line):
        line = fichier.readline()
    return 0
        